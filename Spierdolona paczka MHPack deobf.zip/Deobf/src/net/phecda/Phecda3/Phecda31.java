package net.phecda.Phecda3;

import java.util.function.Consumer;

final class a implements Consumer {
    public void Phecda04(String var1) {
        Phecda04().b().put(var1, Phecda04().a().getProperty(var1));
    }
        //PhecdaTeam Deobfuscator ERROR 0x9333
    public void accept(Object var1) {
        this.Phecda04((String)var1);
    }
}
