package net.phecda.Phecda3;

import java.util.function.BiConsumer;

final class b implements BiConsumer {
    public void Phecda32(String var1, String var2) {
        Phecda32().a().setProperty(var1, var2);
    }

    // $FF: synthetic method
    public void accept(Object var1, Object var2) {
        this.Phecda32((String)var1, (String)var2);
    }
}
