package net.phecda.Phecda3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;

public class Phecda3 {
    private static Properties Phecda439 = new Properties();
    private static Map a = new ConcurrentHashMap();
    private static File b;

    public static void Phecda304() {
        File var0 = new File(Minecraft.x().u, "MHPack");
        if (!var0.exists()) {
            var0.mkdir();
        }

        b = new File(var0, "Opcje.properties");
        if (!b.exists()) {
            b.createNewFile();
        }

        FileInputStream var1 = new FileInputStream(b);
        Phecda439.load(var1);
        a.clear();
        Phecda439.stringPropertyNames().forEach(new a());
    }

    private static void c() {
        if (b != null) {
            FileOutputStream var0 = new FileOutputStream(b);
            a.forEach(new b());
            Phecda439.store(var0, (String)null);
        }

    }

    public static String Phecda3054(String var0) {
        return (String)a.get(var0);
    }

    public static void Phecda94(String var0, String var1) {
        a.remove(var0);
        a.put(var0, var1);

        try {
            c();
            Phecda439();
        } catch (Exception var3) {
            var3.printStackTrace();
        }

    }

    // $FF: synthetic method
    static Properties a() {
        return Phecda439;
    }

    // $FF: synthetic method
    static Map b() {
        return a;
    }
}
