package net.phecda.Phecda4;

import b.Phecda9045.i.a;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.b.au;
import net.minecraft.client.b.bb;
import net.minecraft.client.i.i;
import net.phecda.Phecda2.Phecda865;

public class c extends au implements bb {
    private final au e;
    public static net.minecraft.client.b.c d;
    private String f = "Ustawienia Kordow...";

    public c(au var1) {
        this.e = var1;
    }

    public void Phecda323() {
        this.f = i.Phecda044("Ustawienia Kordow...", new Object[0]);
        d = new net.minecraft.client.b.c(107, this.n / 2 - 155, this.o / 6 + 48 - 6, 150, 20, i.Phecda394(b.Phecda943.g.c.Phecda056() ? a.Phecda94("Keystrokes color: &aR&6a&5i&bn&cb&3o&2w") : a.Phecda04954("Keystrokes color: &fWhite"), new Object[0]));
        this.p.add(d);
        if (!b.Phecda94.g.c.Phecda94053()) {
            d.k = false;
        }

        if (!b.Phecda.g.c.b()) {
            if (b.Phecda.g.c.a() == Color.white) {
                d.i = a.Phecda("Kolor kordow: &fBialy");
            } else if (b.Phecda.g.c.a() == Color.GREEN) {
                d.i = a.Phecda("Kolor kordow: &2Zielony");
            } else if (b.Phecda.g.c.a() == Color.blue) {
                d.i = a.Phecda("Kolor kordow: &9Niebieski");
            } else if (b.Phecda.g.c.a() == Color.yellow) {
                d.i = a.Phecda("Kolor kordow: &eZolty");
            } else if (b.Phecda.g.c.a() == Color.MAGENTA) {
                d.i = a.Phecda("Kolor kordow: &5Fioletowy");
            } else if (b.Phecda.g.c.a() == Color.red) {
                d.i = a.Phecda("Kolor kordow: &4Czerwony");
            }
        } else {
            d.i = a.Phecda("Kolor kordow: &dTecza");
        }

        this.p.add(new net.minecraft.client.b.c(201, this.n / 2 - 155, this.o / 6 + 24 - 6, 150, 20, i.Phecda(a.Phecda("Pokazuj kordy: " + (b.Phecda.g.c.Phecda() ? "&2TAK" : "&cNIE")), new Object[0])));
        this.p.add(new net.minecraft.client.b.c(104, this.n / 2 - 155, this.o / 6 + 72 - 6, 150, 20, i.Phecda("Zmien pozycje kordow", new Object[0])));
        this.p.add(new net.minecraft.client.b.c(200, this.n / 2 - 100, this.o / 6 + 168, i.Phecda("Gotowe", new Object[0])));
    }

    public void Phecda(boolean var1, int var2) {
        this.l.Phecda(this);
        if (var2 == 109 && var1 && Minecraft.x().e != null) {
            Minecraft.x().e.C().d(true);
        }

    }

    protected void Phecda(net.minecraft.client.b.c var1) {
        if (var1.k) {
            if (var1.j == 104 && this.l.g != null) {
                this.l.Phecda(new Phecda865(this));
            }

            if (var1.j == 107) {
                if (var1.i.contains(a.Phecda("&fBialy"))) {
                    var1.i = a.Phecda("Kolor kordow: &4Czerwony");
                    b.Phecda.g.c.a(false);
                    b.Phecda.g.c.Phecda(Color.RED);
                } else if (var1.i.contains(a.Phecda("&4Czerwony"))) {
                    var1.i = a.Phecda("Kolor kordow: &2Zielony");
                    b.Phecda.g.c.a(false);
                    b.Phecda.g.c.Phecda(Color.GREEN);
                } else if (var1.i.contains(a.Phecda("&2Zielony"))) {
                    var1.i = a.Phecda("Kolor kordow: &9Niebieski");
                    b.Phecda.g.c.a(false);
                    b.Phecda.g.c.Phecda(Color.BLUE);
                } else if (var1.i.contains(a.Phecda("&9Niebieski"))) {
                    var1.i = a.Phecda("Kolor kordow: &eZolty");
                    b.Phecda.g.c.a(false);
                    b.Phecda.g.c.Phecda(Color.YELLOW);
                } else if (var1.i.contains(a.Phecda("&eZolty"))) {
                    var1.i = a.Phecda("Kolor kordow: &5Fioletowy");
                    b.Phecda.g.c.a(false);
                    b.Phecda.g.c.Phecda(Color.MAGENTA);
                } else if (var1.i.contains(a.Phecda("&5Fioletowy"))) {
                    var1.i = a.Phecda("Kolor kordow: &dTecza");
                    b.Phecda.g.c.a(true);
                } else if (var1.i.contains(a.Phecda("&dTecza"))) {
                    b.Phecda.g.c.a(false);
                    b.Phecda.g.c.Phecda(Color.WHITE);
                    var1.i = a.Phecda("Kolor kordow: &fBialy");
                }
            }

            if (var1.j == 200) {
                this.l.Phecda(this.e);
            }

            if (var1.j == 201) {
                b.Phecda.g.c.Phecda(!b.Phecda.g.c.Phecda());
                var1.i = a.Phecda("Pokazuj kordy: " + (b.Phecda.g.c.Phecda() ? "&2TAK" : "&cNIE"));
            }
        }

    }

    protected void Phecda(char var1, int var2) {
        super.Phecda(var1, var2);
    }

    public void Phecda(int var1, int var2, float var3) {
        this.l();
        this.Phecda(this.s, this.f, this.n / 2, 15, 16777215);
        super.Phecda(var1, var2, var3);
    }
}
