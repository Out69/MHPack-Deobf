package net.phecda.Phecda4;

import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;


public class GuiUpdateCheck extends GuiScreen {
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, I18n.format(ChatUtils.repairColors("Ladowanie Paczki..."), new Object[0]), this.width / 2, 100, 16777215);
        this.mc.displayGuiScreen(new GuiMainMenu());
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
dsd