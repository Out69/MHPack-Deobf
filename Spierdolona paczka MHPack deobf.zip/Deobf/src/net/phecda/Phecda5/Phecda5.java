package net.phecda.Phecda5;

import b.Phecda.h.Phecda;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class c {
    public static List Phecda = new ArrayList();

    public static void Phecda() {
        Phecda.clear();

        try {
            URL var0 = new URL("http://xbartektm.ct8.pl/tails.txt");
            URLConnection var1 = var0.openConnection();
            BufferedReader var2 = new BufferedReader(new InputStreamReader(var1.getInputStream()));

            String var3;
            while((var3 = var2.readLine()) != null) {
                if (var3.contains(":")) {
                    String var4 = "";
                    boolean var5 = false;
                    String[] var6 = var3.split(":");
                    var4 = var6[0];
                    int var8 = Integer.valueOf(var6[1]);
                    Phecda.add(new Phecda(var4, var8));
                }
            }
        } catch (IOException var7) {
        }

    }

    public static int Phecda(String var0) {
        int var1 = 997;
        Iterator var2 = Phecda.iterator();

        while(var2.hasNext()) {
            Phecda(); var3 = (Phecda())var2.next();
            if (var3.Phecda().equalsIgnoreCase(var0)) {
                var1 = var3.a();
            }
        }

        return var1;
    }

    public static boolean a(String var0) {
        boolean var1 = false;
        Iterator var2 = Phecda.iterator();

        while(var2.hasNext()) {
            Phecda(); var3 = (Phecda())var2.next();
            if (var3.Phecda().equalsIgnoreCase(var0)) {
                var1 = true;
            }
        }

        return var1;
    }

    public static String a() {
        return ((Phecda())Phecda.get(Phecda.size() - 1)).Phecda.Phecda();
    }

    public static boolean b() {
        return Phecda.isEmpty();
    }
}
