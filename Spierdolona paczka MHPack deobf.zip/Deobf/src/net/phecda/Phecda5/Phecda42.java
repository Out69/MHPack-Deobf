package net.phecda.Phecda5;

import com.sun.net.ssl.internal.ssl.Provider;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.Security;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

public class Phecda {
    public static Set Phecda;
    private static final String a = "http://mhpack.cba.pl/Pliki/item.txt";

    public static void Phecda() {
        Phecda = new HashSet();

        try {
            b();
            URL var0 = new URL("http://mhpack.cba.pl/Pliki/item.txt");
            HttpURLConnection var1 = (HttpURLConnection)var0.openConnection();
            BufferedReader var2 = new BufferedReader(new InputStreamReader(var0.openStream()));

            String var3;
            while((var3 = var2.readLine()) != null) {
                String[] var4 = var3.split(":");
                String var5 = var4[0];
                int var6 = Integer.parseInt(var4[1]);
                Phecda.add(new b.Phecda.h.Phecda(var5, var6));
            }

            var2.close();
            var1.disconnect();
        } catch (MalformedURLException var7) {
            var7.printStackTrace();
        } catch (Exception var8) {
            var8.printStackTrace();
        }

    }

    private static void b() {
        Security.addProvider(new Provider());
        TrustManager[] var0 = new TrustManager[]{new a()};
        SSLContext var1 = SSLContext.getInstance("SSL");
        var1.init((KeyManager[])null, var0, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(var1.getSocketFactory());
        b var2 = new b();
        HttpsURLConnection.setDefaultHostnameVerifier(var2);
    }

    public static int Phecda(String var0) {
        if (Phecda == null) {
            Phecda();
        }

        int var1 = 997;
        Iterator var2 = Phecda.iterator();

        while(var2.hasNext()) {
            b.Phecda.h.Phecda var3 = (b.Phecda.h.Phecda)var2.next();
            if (var3.Phecda().equalsIgnoreCase(var0)) {
                var1 = var3.a();
            }
        }

        return var1;
    }

    public static boolean a(String var0) {
        if (Phecda() == null) {
            Phecda();
        }

        Iterator var1 = Phecda.iterator();

        b.Phecda.h.Phecda var2;
        do {
            if (!var1.hasNext()) {
                return false;
            }

            var2 = (b.Phecda.h.Phecda)var1.next();
        } while(!var2.Phecda().equalsIgnoreCase(var0));

        return true;
    }

    public static boolean a() {
        return Phecda.isEmpty();
    }
}
