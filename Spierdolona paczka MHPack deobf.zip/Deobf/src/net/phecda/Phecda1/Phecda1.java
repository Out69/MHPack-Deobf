package Phecda1;

import Phecda.Phecda35.Phecda210.b;
import Phecda.Phecda.Phecda20.a.a;
import Phecda.Phecda45.f.e;
import org.lwjgl.opengl.Display;

public class Phecda1 {
    public static void Phecda139() {
        (new e()).Phecda294();
        Display.setTitle("MHPack | Najlepsza Paczka AntyCheat 1.8.8");

        try {
            P.Phecda43.b.Phecda305.Phecda506();
            P.Phecda294.Phecda340();
        } catch (Exception var1) {
            var1.printStackTrace();
        }

    }
}
