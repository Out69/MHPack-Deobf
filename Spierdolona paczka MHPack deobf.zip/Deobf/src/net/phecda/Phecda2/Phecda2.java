package Phecda2;

import net.minecraft.client.b.au;

public class Phecda2 extends au {
    private final String d;
    private net.minecraft.p.p.Phecda32 e;

    public Phecda302(String var1) {
        this.d = var1;
    }

    public void Phecda546(int var1, int var2, float var3) {
        this.l();
        this.Phecda245(this.s, "Ă‚Â§cTwoj nick: " + this.l.J().b(), this.n / 2, 110, 16777215);
        this.Phecda246(this.s, "Ă‚Â§cOtrzymales blackliste!", this.n / 2, 90, 16777215);
        this.Phecda247(this.s, "Ă‚Â§6Powod: Ă‚Â§f" + this.d, this.n / 2, 100, 16777215);
        super.Phecda305(var1, var2, var3);
    }

    }
}
