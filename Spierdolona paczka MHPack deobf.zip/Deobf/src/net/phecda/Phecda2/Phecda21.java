package net.phecda.Phecda2;

        import java.io.IOException;
        import java.net.URL;
        import java.util.Scanner;
        import net.minecraft.client.Minecraft;


public class Phecda865 {
    public static void check(Minecraft mc) {
        try {
            String name = mc.getSession().getUsername();

            String uuid;
            try {
                uuid = mc.getSession().getProfile().getId().toString();
            } catch (NullPointerException var8) {
                uuid = null;
            }

            Scanner var3 = new Scanner((new URL("http://mhpack.cba.pl/Pliki/blacklist.txt")).openStream());

            while(scanner.hasNextLine()) {
                String[] split = scanner.nextLine().split(":");
                String s = split[0];
                String reason = split[1];
                String time = split[2];
                if (name.equalsIgnoreCase(s)) {
                    mc.displayGuiScreen(new Phecda4(reason, time));
                }

                if (uuid != null && uuid.equals(s)) {
                    mc.displayGuiScreen(new Phecda39(reason, time));
                }
            }
        } catch (IOException var9) {
            var9.printStackTrace();
        }

    }
}
